let viewBtn = document.getElementById("viewbtn")
let display = document.getElementById("hidden")
let display2 = document.getElementById("hidden2")
let display3 = document.getElementById("hidden3")

viewBtn.addEventListener("click", function(){
    display.style.display = "block";
    display2.style.display = "block";
    display3.style.display = "block";
    viewBtn.style.display = "none";
})